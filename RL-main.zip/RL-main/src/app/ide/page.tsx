import MainView from '@/features/main/components/main.view';

const Page = () => {
  return <MainView />;
};

export default Page;
