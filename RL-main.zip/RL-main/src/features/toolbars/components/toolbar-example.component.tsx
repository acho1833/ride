interface Props {
  text: string;
}

const ToolbarExampleComponent = ({ text }: Props) => {
  return <div>{text}</div>;
};

export default ToolbarExampleComponent;
